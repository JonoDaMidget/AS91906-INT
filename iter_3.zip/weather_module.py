"""This module requests location information and connects to the API."""

import geocoder as gc
from geopy.geocoders import Nominatim
import pyowm
from tkinter import Tk
from tkinter.messagebox import askyesno

root = Tk()
root.lift()
root.withdraw()
string = '''CBT would like to access your location.
Grant access to this application to access weather functions
'''
allowloc = askyesno('Permissions Required', string)

if allowloc is True:
    g = gc.ip('me')
    location = Nominatim(user_agent='GetLoc')
    location_name = location.reverse(g.latlng)
    location = location_name.address
    locationlist = location.split(sep=', ')
    owm = pyowm.OWM('API KEY HERE')
    weather_mgr = owm.weather_manager()
    observation = weather_mgr.weather_at_place(locationlist[-3])
    temperature = observation.weather.temperature('celsius')['temp']
    humidity = observation.weather.humidity
    wind = observation.weather.wind()
    weather = observation.weather.status
    root.destroy()
else:
    root.destroy()
