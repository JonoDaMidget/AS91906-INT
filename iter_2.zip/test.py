from tkinter.ttk import Combobox
from tkinter import Tk, StringVar


root = Tk()

def justamethod(event):
    print('Method Called')
    print(locationBox.get())

box_value = StringVar()
locationBox = Combobox(root)
locationBox.bind("<<ComboboxSelected>>", justamethod)
locationBox['values'] = ('one', 'two', 'three')
locationBox.current(0)
locationBox.pack()


root.mainloop()